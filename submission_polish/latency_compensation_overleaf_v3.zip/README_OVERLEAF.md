# IEEE Transactions Overleaf Package

## Main files
- `main.tex` — main manuscript; set this as the Overleaf Main document.
- `supplement.tex` — supplementary material; compile separately when needed.
- `IEEEtran.cls` — official IEEE Transactions class supplied with the uploaded IEEE template.
- `references.bib` — bibliography database.
- `figures/` — manuscript figures in PDF and PNG formats.
- `source_data/` — aggregate source tables and audit records.

## Overleaf setup
1. Upload this ZIP as a new Overleaf project.
2. Open **Menu → Main document** and select `main.tex`.
3. Use **pdfLaTeX** as the compiler.
4. Overleaf will run BibTeX automatically. If references do not appear on the first compilation, use **Recompile from scratch**.

## IEEE formatting changes applied
- Uses the official `IEEEtran.cls` with `\documentclass[journal]{IEEEtran}`.
- Uses the standard IEEE author/affiliation footnote structure.
- Adds the IEEE `cite` package for compressed numerical citations.
- Removes the `balance` package and both `\balance` calls that caused the second-column warning.
- Uses IEEE-style top-float placement requests (`[!t]`).
- Retains `\bibliographystyle{IEEEtran}`.

## Remaining submission placeholders
Before submission, replace:
- repository release URL and archival DOI in the Data and Code Availability section;
- author-contribution text if additional authors are added;
- funding and institutional-computing acknowledgment.

The project includes the official IEEE LaTeX instructions under `ieee_template_docs/` for reference only.
